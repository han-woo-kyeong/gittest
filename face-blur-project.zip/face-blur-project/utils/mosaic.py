# Placeholder for mosaic utilities
